<?php
 class Db{
    private $bd;
    function __construct(){
           $this->bd=new PDO('mysql:host=localhost;dbname=admin','root','');
    }

    function connect(){
        return $this->bd;
    }
}

// $host     = 'localhost';
// $user     = 'root';
// $password = '';
// $database = 'admin';


?>